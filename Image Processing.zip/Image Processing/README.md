## Image Processing

1. Converting the image to grayscale
2. Splitting the image into channels